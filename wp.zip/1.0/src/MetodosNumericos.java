/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import consola.Menu;
import consola.MenuCallback;
import metodos.*;

/**
 *
 * @author Gerson
 */
public class MetodosNumericos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Menu menu = new Menu();
        menu.setTitulo("Analisis y Estudio de viabilidad del uso de la programacion funcional \n para la solucion de metodos numericos de ingenieria \n" +
"\n" +
"Integrantes :\n" +
"-Michael Felipe Corrales Florez - 1007423576\n" +
"-Harold Steven Soto Niño 1092391053");
        
        menu.agregar("Gauss", new MenuCallback() {
            public void ejecutar() {
                Gauss metodo = new Gauss();
                metodo.consola();
            }
        });
        menu.agregar("Gauss-Jordan", new MenuCallback() {
            public void ejecutar() {
                GaussJordan metodo = new GaussJordan();
                metodo.consola();
            }
});
        menu.agregar("Metodo de Euler", new MenuCallback() {
            public void ejecutar() {
                Euler metodo = new Euler();
                metodo.consola();
            }
        });
        menu.agregar("Metodo de Euler Mejorado", new MenuCallback() {
            public void ejecutar() {
                EulerMejorado metodo = new EulerMejorado();
                metodo.consola();
            }
        });
        menu.agregar("Metodo de Runge Kutta", new MenuCallback() {
            public void ejecutar() {
                RungeKutta metodo = new RungeKutta();
                metodo.consola();
            }
        });




        menu.mostrar();
    }
}
