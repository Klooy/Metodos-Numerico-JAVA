package de.congrace.exp4j;

public class InvalidCustomFunctionException extends Exception {
	private static final long serialVersionUID = 1L;

	public InvalidCustomFunctionException(String message) {
		super(message);
	}
}
